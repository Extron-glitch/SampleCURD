import React, { useRef, useState, useEffect } from "react";
import { Button } from "../components/ui/button";

const DEFAULT_URL = "https://extron-glitch.github.io/my-bookmarks";

const WebviewPage: React.FC = () => {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [inputUrl, setInputUrl] = useState("");
  const webviewRef = useRef<any>(null);
  const componentId = useRef(Math.random().toString(36).substr(2, 9));
  const [isWebviewReady, setIsWebviewReady] = useState(false);
  

  useEffect(() => {
    console.log(`WebviewPage [${componentId.current}] mounted.`);
    return () => {
      console.log(`WebviewPage [${componentId.current}] unmounted.`);
    };
  }, []);

  useEffect(() => {
    const webview = webviewRef.current;
    if (!webview) return;

    console.log(`Webview [${componentId.current}] useEffect triggered.`);

    // Wait for the webview to be properly initialized before attaching listeners
    const handleDomReady = () => {
      console.log(`Webview [${componentId.current}] DOM ready`);
      setIsWebviewReady(true);
    
      try {
        if (webview.executeJavaScript) {
          // ✅ Inject safe cursor styles
          webview.executeJavaScript(`
            (function() {
              try {
                const style = document.createElement('style');
                style.id = '__safe_cursor_style';
                style.textContent = \`
                  html, body, input, textarea, button, a, [contenteditable="true"] {
                    cursor: default !important;
                  }
                \`;
                document.head.appendChild(style);
              } catch (err) {
                console.warn('Cursor injection error:', err);
              }
            })();
          `).catch((error) => {
            console.warn("Failed to inject cursor style:", error);
          });
    
          // ✅ Inject mutation observer for new interactive elements
          webview.executeJavaScript(`
            (function() {
              try {
                const applyCursor = (node) => {
                  if (
                    node.tagName &&
                    ['INPUT', 'TEXTAREA', 'BUTTON', 'A'].includes(node.tagName)
                  ) {
                    node.style.cursor = 'default';
                  }
                };
    
                const observer = new MutationObserver((mutations) => {
                  mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach(node => {
                      if (node.nodeType === 1) {
                        applyCursor(node);
                        node.querySelectorAll && node.querySelectorAll('input, textarea, button, a').forEach(applyCursor);
                      }
                    });
                  });
                });
    
                observer.observe(document.body, { childList: true, subtree: true });
              } catch (err) {
                console.warn('Cursor mutation observer error:', err);
              }
            })();
          `).catch((error) => {
            console.warn("Failed to inject cursor mutation observer:", error);
          });
    
          // ✅ Inject Gemini dictation script (toggle 🎤/⏹️ buttons)
          window.electronAPI.getGeminiCredentials().then(
            ({ apiKey, model }: { apiKey: string; model: string }) => {
              webview.executeJavaScript(`
                (function() {
                  // Safe cursor styles for only relevant elements
                  try {
                    const style = document.createElement('style');
                    style.id = '__safe_cursor_style';
                    style.textContent = \`
                      input, textarea, button, a, div[contenteditable="true"] {
                        cursor: default !important;
                      }
                    \`;
                    document.head.appendChild(style);
                  } catch (err) {
                    console.warn('Cursor injection error:', err);
                  }

                  // Dictation script
                  (async () => {
                    const { GoogleGenerativeAI } = await import("https://esm.run/@google/generative-ai");
                    const model = new GoogleGenerativeAI("${apiKey}").getGenerativeModel({ model: "${model}" });

                    function wrapIfNeeded(field) {
                      // Only wrap if not already wrapped
                      if (field.parentElement && field.parentElement.classList.contains('__mic_wrap')) return field.parentElement;
                      const wrapper = document.createElement('div');
                      wrapper.style.position = 'relative';
                      wrapper.className = '__mic_wrap';
                      // Copy computed width/height if possible
                      const rect = field.getBoundingClientRect();
                      if (rect.width) wrapper.style.width = rect.width + 'px';
                      if (rect.height) wrapper.style.height = rect.height + 'px';
                      // Insert wrapper before field, then move field inside
                      field.parentNode.insertBefore(wrapper, field);
                      wrapper.appendChild(field);
                      return wrapper;
                    }

                    function injectMicButtons() {
                      // For input[type=text] and textarea
                      const fields = Array.from(document.querySelectorAll("input[type='text'], textarea"));
                      fields.forEach(field => {
                        if (field.dataset.dictateAttached) return;
                        const btn = document.createElement("button");
                        btn.textContent = "🎤";
                        btn.style.marginLeft = "5px";
                        btn.style.fontSize = "14px";
                        btn.style.padding = "4px 6px";
                        btn.title = "Dictate with Gemini";
                        btn.style.cursor = "pointer";
                        btn.style.background = "rgba(0,0,0,0.7)";
                        btn.style.color = "#fff";
                        btn.style.border = "none";
                        btn.style.borderRadius = "6px";
                        btn.style.opacity = "0.85";
                        btn.style.transition = "opacity 0.2s";
                        btn.onmouseenter = () => btn.style.opacity = "1";
                        btn.onmouseleave = () => btn.style.opacity = "0.85";
                        let isRecording = false;
                        let recorder = null;
                        let stream = null;
                        let chunks = [];
                        btn.onclick = async () => {
                          if (!isRecording) {
                            try {
                              stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                              recorder = new MediaRecorder(stream);
                              chunks = [];
                              recorder.ondataavailable = e => chunks.push(e.data);
                              recorder.onstop = async () => {
                                const blob = new Blob(chunks, { type: 'audio/webm' });
                                const base64 = await blobToBase64(blob);
                                const prompt = "Transcribe this audio as accurately as possible. The content is likely related to software engineering interviews, specifically involving Java, Spring Boot, REST APIs, AWS, GCP, Docker, Kubernetes, SQL, NoSQL, or system design. Prioritize precise recognition of technical terms, programming keywords, cloud services, acronyms, and code-like phrases. Do not paraphrase, rephrase, or summarize — preserve the original spoken structure. Return **only** the raw transcribed text without any explanations, formatting, or extra characters.";
                                try {
                                  const result = await model.generateContent([
                                    prompt,
                                    { inlineData: { data: base64, mimeType: blob.type } }
                                  ]);
                                  const response = await result.response;
                                  const text = await response.text();
                                  if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
                                    field.value = text;
                                  }
                                  field.dispatchEvent(new Event('input', { bubbles: true }));
                                } catch (err) {
                                  console.error("Transcription failed:", err);
                                }
                                stream.getTracks().forEach(t => t.stop());
                                stream = null;
                                recorder = null;
                              };
                              recorder.start();
                              isRecording = true;
                              btn.textContent = "⏹️";
                            } catch (err) {
                              console.error("Mic access failed:", err);
                            }
                          } else {
                            recorder.stop();
                            isRecording = false;
                            btn.textContent = "🎤";
                          }
                        };
                        field.insertAdjacentElement("afterend", btn);
                        field.dataset.dictateAttached = "true";
                      });

                      // For div[contenteditable="true"]
                      const editables = Array.from(document.querySelectorAll('div[contenteditable="true"]'));
                      editables.forEach(field => {
                        if (field.dataset.dictateAttached) return;
                        const wrapper = wrapIfNeeded(field);
                        // Only add one mic button per wrapper
                        if (wrapper.querySelector('.__mic_btn')) return;
                        const btn = document.createElement("button");
                        btn.textContent = "🎤";
                        btn.className = "__mic_btn";
                        btn.style.position = "absolute";
                        btn.style.bottom = "4px";
                        btn.style.right = "4px";
                        btn.style.zIndex = "9999";
                        btn.style.fontSize = "14px";
                        btn.style.padding = "4px 6px";
                        btn.style.background = "rgba(0,0,0,0.7)";
                        btn.style.color = "#fff";
                        btn.style.border = "none";
                        btn.style.borderRadius = "6px";
                        btn.style.opacity = "0.85";
                        btn.style.transition = "opacity 0.2s";
                        btn.onmouseenter = () => btn.style.opacity = "1";
                        btn.onmouseleave = () => btn.style.opacity = "0.85";
                        let isRecording = false;
                        let recorder = null;
                        let stream = null;
                        let chunks = [];
                        btn.onclick = async () => {
                          if (!isRecording) {
                            try {
                              stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                              recorder = new MediaRecorder(stream);
                              chunks = [];
                              recorder.ondataavailable = e => chunks.push(e.data);
                              recorder.onstop = async () => {
                                const blob = new Blob(chunks, { type: 'audio/webm' });
                                const base64 = await blobToBase64(blob);
                                const prompt = "Transcribe this audio as accurately as possible. The content is likely related to software engineering interviews, specifically involving Java, Spring Boot, REST APIs, AWS, GCP, Docker, Kubernetes, SQL, NoSQL, or system design. Prioritize precise recognition of technical terms, programming keywords, cloud services, acronyms, and code-like phrases. Do not paraphrase, rephrase, or summarize — preserve the original spoken structure. Return **only** the raw transcribed text without any explanations, formatting, or extra characters.";
                                try {
                                  const result = await model.generateContent([
                                    prompt,
                                    { inlineData: { data: base64, mimeType: blob.type } }
                                  ]);
                                  const response = await result.response;
                                  const text = await response.text();
                                  field.innerText = text;
                                  field.dispatchEvent(new Event('input', { bubbles: true }));
                                } catch (err) {
                                  console.error("Transcription failed:", err);
                                }
                                stream.getTracks().forEach(t => t.stop());
                                stream = null;
                                recorder = null;
                              };
                              recorder.start();
                              isRecording = true;
                              btn.textContent = "⏹️";
                            } catch (err) {
                              console.error("Mic access failed:", err);
                            }
                          } else {
                            recorder.stop();
                            isRecording = false;
                            btn.textContent = "🎤";
                          }
                        };
                        wrapper.appendChild(btn);
                        field.dataset.dictateAttached = "true";
                      });
                    }

                    function blobToBase64(blob) {
                      return new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result.split(",")[1]);
                        reader.onerror = reject;
                        reader.readAsDataURL(blob);
                      });
                    }

                    setInterval(injectMicButtons, 1500);
                  })();
                })();
              `).catch((err) => console.warn("Dictate injection failed:", err));
            }
          );
        }
      } catch (error) {
        console.warn("Error injecting scripts:", error);
      }
    };
    

    const handleDidFinishLoad = () => {
      console.log(`Webview [${componentId.current}] did-finish-load:`, webview.getURL?.());
    };

    const handleDidFailLoad = (event: any) => {
      console.error(`Webview [${componentId.current}] did-fail-load:`, {
        errorCode: event.errorCode,
        errorDescription: event.errorDescription,
        validatedURL: event.validatedURL,
      });
    };

    const handleCrashed = () => {
      console.error(`Webview [${componentId.current}] crashed`);
      setIsWebviewReady(false);
    };

    const handleUnresponsive = () => {
      console.error(`Webview [${componentId.current}] unresponsive`);
    };

    const handleResponsive = () => {
      console.log(`Webview [${componentId.current}] responsive`);
    };

    // Attach event listeners
    webview.addEventListener("dom-ready", handleDomReady);
    webview.addEventListener("did-finish-load", handleDidFinishLoad);
    webview.addEventListener("did-fail-load", handleDidFailLoad);
    webview.addEventListener("crashed", handleCrashed);
    webview.addEventListener("unresponsive", handleUnresponsive);
    webview.addEventListener("responsive", handleResponsive);
    
    console.log(`Webview [${componentId.current}] event listeners attached.`);

    // Clean up function
    return () => {
      if (webview) {
        try {
          webview.removeEventListener("dom-ready", handleDomReady);
          webview.removeEventListener("did-finish-load", handleDidFinishLoad);
          webview.removeEventListener("did-fail-load", handleDidFailLoad);
          webview.removeEventListener("crashed", handleCrashed);
          webview.removeEventListener("unresponsive", handleUnresponsive);
          webview.removeEventListener("responsive", handleResponsive);
          console.log(`Webview [${componentId.current}] event listeners removed.`);
        } catch (error) {
          console.warn("Error removing webview listeners:", error);
        }
      }
    };
  }, []);

  // Load URL in webview when url state changes
  useEffect(() => {
    const webview = webviewRef.current;
    if (!webview || !isWebviewReady) return;

    console.log(`Loading URL in webview: ${url}`);
    try {
      // Only call loadURL when webview is fully ready
      if (typeof webview.loadURL === "function") {
        webview.loadURL(url).catch((error: any) => {
          console.error("Failed to load URL:", error);
        });
      } else {
        // Fallback
        webview.src = url;
      }
    } catch (error) {
      console.error("Error loading URL:", error);
    }
  }, [url, isWebviewReady]);

  // Debug log url changes
  useEffect(() => {
    console.log(`URL state changed to: ${url}`);
  }, [url]);

  // Only inject error handling script when webview is ready
  useEffect(() => {
    const webview = webviewRef.current;
    if (!webview || !isWebviewReady) return;

    try {
      // Safely execute JavaScript in the webview
      if (webview.executeJavaScript) {
        webview.executeJavaScript(`
          window.addEventListener('error', (event) => {
            console.error('Unhandled exception in webview:', event.error);
          });
        `).catch((error: any) => {
          console.warn("Failed to inject error handler:", error);
        });
      }
    } catch (error) {
      console.warn("Error injecting scripts:", error);
    }
  }, [isWebviewReady]);

  const handleLoadUrl = () => {
    // Get the trimmed input URL
    const trimmedInput = inputUrl.trim();
    
    // If no URL is entered, use the default URL
    if (!trimmedInput) {
      console.log("No URL entered, loading default URL:", DEFAULT_URL);
      setUrl(DEFAULT_URL);
      
      // Direct webview manipulation if ready
      const webview = webviewRef.current;
      if (webview && isWebviewReady) {
        try {
          if (typeof webview.loadURL === "function") {
            webview.loadURL(DEFAULT_URL).catch((error: any) => {
              console.error("Failed to load default URL:", error);
            });
          } else {
            webview.src = DEFAULT_URL;
          }
        } catch (error) {
          console.error("Error loading default URL:", error);
        }
      }
      return;
    }

    // Process and load the entered URL
    let correctedUrl = trimmedInput;
    if (!/^https?:\/\//i.test(correctedUrl)) {
      correctedUrl = `https://${correctedUrl}`;
      setInputUrl(correctedUrl);
    }

    console.log("Loading user-entered URL:", correctedUrl);
    setUrl(correctedUrl);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleLoadUrl();
    }
  };

  return (
    <div className="flex flex-col items-center w-full h-full p-4">
      <div className="w-full md:w-2/3 lg:w-1/2 mb-4 flex gap-2">
        <input
          type="text"
          className="flex-1 px-3 py-2 rounded bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={inputUrl}
          onChange={(e) => setInputUrl(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter URL (e.g., google.com)"
          style={{ cursor: 'default' }}
        />
        <Button 
          onClick={handleLoadUrl}
          style={{ cursor: 'default' }}
        >
          Load
        </Button>
      </div>
      <div className="w-full md:w-2/3 lg:w-1/2 h-96 md:h-[600px] border border-white/10 rounded-lg overflow-hidden bg-white/5">
        {window?.electronAPI ? (
          <webview
            ref={webviewRef}
            src={DEFAULT_URL}
            className="w-full h-full"
            allowpopups={true}
            webpreferences="nativeWindowOpen=yes, contextIsolation=yes"
            partition="persist:webviewsession"
            style={{ cursor: 'default' }}
          />
        ) : (
          <iframe
            src={url}
            title="Webview"
            className="w-full h-full border-none bg-white"
            sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
            style={{ cursor: 'default' }}
          />
        )}
      </div>
    </div>
  );
};

export default WebviewPage;