export interface Screenshot {
  path: string
  preview: string
}
